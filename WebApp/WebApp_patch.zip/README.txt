Instrucciones (Frontend):
1) Reemplaza `src/context/AuthContext.jsx` y `src/lib/api.js`.
2) Crea `.env.local` con: VITE_API_URL=http://localhost:8083
3) Reinicia el front.
