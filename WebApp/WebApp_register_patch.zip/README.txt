1) Reemplaza RegisterForm.jsx por este.
2) Asegúrate de tener VITE_API_URL apuntando al backend (http://localhost:8083).
3) El formulario llama POST /api/register y, si el contexto Auth está disponible, hace auto-login.
